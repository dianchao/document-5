package com.yupi.usercenter.mapper;

import com.yupi.usercenter.model.domain.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @Entity com.yupi.usercenter.model.domain.User
 */
public interface UserMapper extends BaseMapper<User> {

}




