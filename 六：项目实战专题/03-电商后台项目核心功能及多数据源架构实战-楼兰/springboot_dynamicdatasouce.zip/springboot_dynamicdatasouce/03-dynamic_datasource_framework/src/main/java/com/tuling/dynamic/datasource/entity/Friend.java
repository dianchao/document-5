package com.tuling.dynamic.datasource.entity;

import lombok.Data;

/**
 * @Auther: wangyi
 * @Description:
 */
@Data
public class Friend {
    private Long id;

    private String name;

}