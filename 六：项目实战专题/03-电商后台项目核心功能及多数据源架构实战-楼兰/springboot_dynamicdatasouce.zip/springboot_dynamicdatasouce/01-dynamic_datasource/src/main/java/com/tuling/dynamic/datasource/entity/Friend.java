package com.tuling.dynamic.datasource.entity;

import lombok.Data;

@Data
public class Friend {

    private Long id;

    private String name;
}
