package com.tuling.datasource.dynamic.mybatis.entity;

import lombok.Data;

/**
 * @Auther: wangyi
 * @Date: 2020/12/12 01:16
 * @Description:
 */
@Data
public class Friend {
    private Long id;

    private String name;

}