package com.tuling.datasource.dynamic.mybatis.service.transaction;

public class DbTxConstants {

    public static final String DB1_TX = "wTransactionManager";

    public static final String DB2_TX = "rTransactionManager";
}
