package com.tuling.tulingmallauthcenter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TulingmallAuthcenterApplicationTests {

    @Test
    void contextLoads() {
    }

}
