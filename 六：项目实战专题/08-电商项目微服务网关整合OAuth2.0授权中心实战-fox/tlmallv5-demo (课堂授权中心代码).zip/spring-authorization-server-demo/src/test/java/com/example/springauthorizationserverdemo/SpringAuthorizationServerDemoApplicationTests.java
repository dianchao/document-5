package com.example.springauthorizationserverdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAuthorizationServerDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
