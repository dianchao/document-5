package com.example.springauthorizationserverdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringAuthorizationServerDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringAuthorizationServerDemoApplication.class, args);
    }

}
