package com.tulingmall.service.mobilearea;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MobileAreaApp {
    public static void main(String[] args) {
        SpringApplication.run(MobileAreaApp.class);
    }
}
