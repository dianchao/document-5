package com.tlmall.open.domain.hisrequest.infrastructure;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.tlmall.open.domain.hisrequest.entity.HisRequest;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author loulan
 * @desc
 */
@Mapper
public interface HisRequestMapper extends BaseMapper<HisRequest> {
}
