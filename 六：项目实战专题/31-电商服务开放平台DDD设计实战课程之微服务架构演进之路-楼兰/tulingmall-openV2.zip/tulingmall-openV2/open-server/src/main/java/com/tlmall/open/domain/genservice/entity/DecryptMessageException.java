package com.tlmall.open.domain.genservice.entity;

/**
 * @author ：楼兰
 **/

public class DecryptMessageException extends RuntimeException{
    public DecryptMessageException() {
    }

    public DecryptMessageException(String message) {
        super(message);
    }
}
