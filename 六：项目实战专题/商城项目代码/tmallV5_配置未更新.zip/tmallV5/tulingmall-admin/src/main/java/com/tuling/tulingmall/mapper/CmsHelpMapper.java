package com.tuling.tulingmall.mapper;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.tuling.tulingmall.model.CmsHelp;

@DS("normal")
public interface CmsHelpMapper extends BaseMapper<CmsHelp> {
}