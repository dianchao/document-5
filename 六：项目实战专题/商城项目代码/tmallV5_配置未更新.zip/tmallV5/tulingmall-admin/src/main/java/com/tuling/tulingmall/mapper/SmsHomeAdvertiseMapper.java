package com.tuling.tulingmall.mapper;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.tuling.tulingmall.model.SmsHomeAdvertise;
@DS("promotion")
public interface SmsHomeAdvertiseMapper extends BaseMapper<SmsHomeAdvertise> {
}