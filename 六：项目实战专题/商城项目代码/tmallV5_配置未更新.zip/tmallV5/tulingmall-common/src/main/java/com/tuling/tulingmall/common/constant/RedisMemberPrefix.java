package com.tuling.tulingmall.common.constant;

public class RedisMemberPrefix {

    public final static String MEMBER_INFO_PREFIX = "mmbr:info:";
    public final static String MEMBER_ADDRESS_PREFIX = "mmbr:addr:";

}
