package com.tuling.tulingmall.feignapi.pms;

/**
* @vlog: 高于生活，源于生活
* @desc: 类的描述: 订单服务用于调用商品服务锁定库存
* @author: smlz
* @createDate: 2020/3/16 15:25
* @version: 1.0
*/
/*@FeignClient(value = "tulingmall-product",path = "/stock")
public interface PmsProductStockFeignApi {


    @RequestMapping("/lockStock")
    CommonResult lockStock(@RequestBody List<CartPromotionItem> cartPromotionItemList);
}*/
