package com.tuling.tulingmall.service;

public interface IProcessCanalData {

    void connect();
    void disConnect();
    void processData();

}
