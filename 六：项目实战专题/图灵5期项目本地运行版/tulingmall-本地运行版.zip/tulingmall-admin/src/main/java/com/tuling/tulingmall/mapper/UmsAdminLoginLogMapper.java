package com.tuling.tulingmall.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.tuling.tulingmall.model.UmsAdminLoginLog;

public interface UmsAdminLoginLogMapper extends BaseMapper<UmsAdminLoginLog> {
}