package com.tuling.tulingmall.mapper;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.tuling.tulingmall.model.SmsFlashPromotionSession;
@DS("promotion")
public interface SmsFlashPromotionSessionMapper extends BaseMapper<SmsFlashPromotionSession> {
}