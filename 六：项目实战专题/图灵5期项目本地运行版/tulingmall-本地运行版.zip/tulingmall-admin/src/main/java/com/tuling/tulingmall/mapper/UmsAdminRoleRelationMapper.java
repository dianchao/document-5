package com.tuling.tulingmall.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.tuling.tulingmall.model.UmsAdminRoleRelation;

public interface UmsAdminRoleRelationMapper extends BaseMapper<UmsAdminRoleRelation> {
}