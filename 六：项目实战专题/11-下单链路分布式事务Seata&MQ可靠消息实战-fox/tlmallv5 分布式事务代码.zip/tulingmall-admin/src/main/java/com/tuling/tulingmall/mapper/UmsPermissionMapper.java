package com.tuling.tulingmall.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.tuling.tulingmall.model.UmsPermission;

public interface UmsPermissionMapper extends BaseMapper<UmsPermission> {
}