return require "resty.template".new(true)

