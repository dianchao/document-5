package com.myapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author roy
 * @desc
 */
@SpringBootApplication
public class TulingOpenClientApp {

    public static void main(String[] args) {
        SpringApplication.run(TulingOpenClientApp.class,args);
    }
}
