package com.tuling.tulingmall.open.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.tuling.tulingmall.open.entity.ClientInfo;

/**
 * @author 楼兰
 * @desc
 */
public interface ClientInfoMapper extends BaseMapper<ClientInfo> {
}
