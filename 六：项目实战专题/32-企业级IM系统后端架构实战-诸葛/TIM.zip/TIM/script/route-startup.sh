#!/usr/bin/env bash
nohup java -jar  /root/work/route/tim-gateway-1.0.0-SNAPSHOT.jar  > /root/work/route/log.file 2>&1 &