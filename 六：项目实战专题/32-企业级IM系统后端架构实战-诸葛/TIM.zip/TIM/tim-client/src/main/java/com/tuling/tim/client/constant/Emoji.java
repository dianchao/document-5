package com.tuling.tim.client.constant;

/**
 *
 * @since JDK 1.8
 */
public class Emoji {

}
