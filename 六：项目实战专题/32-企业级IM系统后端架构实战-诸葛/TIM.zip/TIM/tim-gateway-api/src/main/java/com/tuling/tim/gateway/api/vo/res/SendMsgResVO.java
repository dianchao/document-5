package com.tuling.tim.gateway.api.vo.res;

/**
 * @since JDK 1.8
 */
public class SendMsgResVO {
    private String msg;

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
