
登录用户：monkey 密码是：123456
sql插入语句：
INSERT INTO `micromall`.`ums_member`(`id`, `member_level_id`, `username`, `password`, `nickname`, `phone`, `status`, `create_time`, `icon`, `gender`, `birthday`, `city`, `job`, `personalized_signature`, `source_type`, `integration`, `growth`, `luckey_count`, `history_integration`) VALUES (8, 4, 'monkey', '$2a$10$Ab5VsAaD.uvoXuKCSzTP0.tBXnJ1aoX08u77tUT7yuu/MFjG59NU2', 'monkey', '18061581844', 1, '2018-11-12 14:22:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6000, NULL, NULL, NULL);
