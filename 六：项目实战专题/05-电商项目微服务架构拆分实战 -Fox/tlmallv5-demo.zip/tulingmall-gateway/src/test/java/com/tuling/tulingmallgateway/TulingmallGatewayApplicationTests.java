package com.tuling.tulingmallgateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TulingmallGatewayApplicationTests {

    @Test
    void contextLoads() {
    }

}
