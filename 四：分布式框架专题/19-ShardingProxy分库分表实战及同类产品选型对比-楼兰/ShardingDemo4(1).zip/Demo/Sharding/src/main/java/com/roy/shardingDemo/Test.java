package com.roy.shardingDemo;

/**
 * @author roy
 * @date 2022/3/29
 * @desc
 */
public class Test {
    public static void main(String[] args) {
        for (long i = 0; i < 100; i++) {
            long database = i % 2 + 1;
            long table = ((i + 1) % 4) / 2 + 1;
            System.out.println("主键："+i+";库分片："+database +":表分片"+table);
        }
        Long l = 1508729680537792515L;
        System.out.println(((l + 1) % 4) / 2);
    }
}
