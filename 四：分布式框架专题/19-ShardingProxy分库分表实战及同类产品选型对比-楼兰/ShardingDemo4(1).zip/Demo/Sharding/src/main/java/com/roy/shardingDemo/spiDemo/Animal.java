package com.roy.shardingDemo.spiDemo;

/**
 * @author ：楼兰
 * @date ：Created in 2021/1/7
 * @description:
 **/
public interface Animal {

    void noise();
}
