package com.roy.shardingDemo;

import com.roy.shardingDemo.transaction.SeataTransactionService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.io.IOException;
import java.sql.SQLException;

/**
 * @author ：楼兰
 * @date ：Created in 2021/4/22
 * @description: Base柔性事务测试案例
 **/
@SpringBootTest
@RunWith(SpringRunner.class)
public class BaseTransactionTest {

    @Resource
    SeataTransactionService service;
    //测试BASE事务管理器
    @Test
    public void baseTransactionTest() throws IOException, SQLException {
//        SeataTransactionService service = new SeataTransactionService("/sharding-databases-tables.yaml");
        service.init();

        service.insert();
        service.insertFailed();
        service.cleanup();
    }

}
