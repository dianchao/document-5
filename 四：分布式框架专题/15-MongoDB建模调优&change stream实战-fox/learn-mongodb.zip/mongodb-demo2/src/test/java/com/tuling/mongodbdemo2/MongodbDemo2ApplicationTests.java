package com.tuling.mongodbdemo2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongodbDemo2ApplicationTests {


}
