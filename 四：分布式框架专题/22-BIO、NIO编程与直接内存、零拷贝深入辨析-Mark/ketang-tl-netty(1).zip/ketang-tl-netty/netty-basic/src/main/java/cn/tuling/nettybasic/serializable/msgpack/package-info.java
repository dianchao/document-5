/**
 * @author Mark老师
 * 类说明：本包中的代码演示了：
 * 1、LengthFieldBasedFrame的使用
 * 2、如何和第三方序列化工具，比如MessagePack进行集成
 * 3、如何实现自己的编解码框架
 */
package cn.tuling.nettybasic.serializable.msgpack;