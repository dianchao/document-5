package com.chenj.springbootehcache.service;


import com.chenj.springbootehcache.entity.User;

public interface EhcacheService {
    User findById(String userId);
    public boolean isReserved(String userId);

    public String refreshData(String key);
    public void removeUser(String userId);

    public void removeAllUser();
}
