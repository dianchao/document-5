package com.chenj.springbootehcache;

import com.chenj.springbootehcache.entity.User;
import com.chenj.springbootehcache.service.EhcacheService;
import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootEhcacheApplicationTests {

    @Test
    void contextLoads() {
    }


    @Autowired
    private EhcacheService ehcacheService;

    @Autowired
    private CacheManager cacheManager;

    @Test
    public void testFindById() {
        User user1 = ehcacheService.findById("1000");
        System.out.println(user1);
        System.out.println("----------------------");

        User user2 = ehcacheService.findById("1000");
        System.out.println(user2);

        System.out.println("-----------------------");
        Cache userCache = cacheManager.getCache("UserCache");
        System.out.println(userCache.getKeys());
        Element element = userCache.get("user:1000");
        System.out.println(element);
    }
}
