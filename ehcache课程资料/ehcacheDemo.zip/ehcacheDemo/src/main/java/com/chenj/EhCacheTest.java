package com.chenj;

import com.chenj.entity.Dog;
import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

public class EhCacheTest {
    public static void main(String[] args) {

        //1,获取CacheManager
        CacheManager cacheManager = CacheManager.create();

        //2,获取Cache实例
        Cache helloWorldCache = cacheManager.getCache("HelloWorldCache");
        
        //3,存入元素
        Element element = new Element("key1","value1");
        
        helloWorldCache.put(element);
        
        //4,取出来
        Element value = helloWorldCache.get("key1");

        String objectValue = (String)value.getObjectValue();

        System.out.println("objectValue:"+objectValue);

        System.out.println("value:"+value);

        //helloWorldCache.remove("key1");

        System.out.println("---------------------------------");

        Dog dog = new Dog("xiaohei", "black", 2);
        Element element2 = new Element("dog", dog);
        helloWorldCache.put(element2);
        Element value2 = helloWorldCache.get("dog");
        System.out.println("value2: "  + value2);
        Dog dog2 = (Dog) value2.getObjectValue();
        System.out.println(dog2);

        System.out.println("缓存实例里面有多少个元素:"+helloWorldCache.getSize());


        //5、关闭
        cacheManager.shutdown();


    }
}
