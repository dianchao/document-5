package com.chenj;

import com.chenj.entity.User;
import com.chenj.service.EhcacheService;
import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@ContextConfiguration(locations = {"classpath:spring/applicationContext.xml","classpath:spring/applicationContext-ehcache.xml"})
@RunWith(SpringJUnit4ClassRunner.class)
public class TestSpringEhCache {
    @Autowired
    private EhcacheService ehcacheService;

    @Autowired
    private CacheManager cacheManager;

    @Test
    public void testFindById(){
        User user1 = ehcacheService.findById("1000");

        System.out.println(user1);

        System.out.println("-----------------------------");

        User user2 = ehcacheService.findById("1000");

        System.out.println(user2);

        System.out.println("-----------------------------");
        Cache userCache = cacheManager.getCache("UserCache");
        System.out.println(userCache.getKeys());
        Element element = userCache.get("EhcacheServiceImpl#findById");
        System.out.println(element);


    }


    @Test
    public void testIsReserved(){
        ehcacheService.isReserved("1000000000000000");

        System.out.println("-------------------------------");

        ehcacheService.isReserved("1000000000000000");

        System.out.println("-----------------------------");
        Cache userCache = cacheManager.getCache("UserCache");

        Element element = userCache.get("1000000000000000");
        System.out.println(element);
    }

    @Test
    public void testCachePut(){
        String key1 = ehcacheService.refreshData("1000");
        System.out.println(key1);
        System.out.println("---------------------------");

        String key2 = ehcacheService.refreshData("1000");
        System.out.println(key2);

        System.out.println("-----------------------------");
        Cache userCache = cacheManager.getCache("UserCache");

        Element element = userCache.get("1000");
        System.out.println(element);
    }


    @Test
    public void testCacheEvict(){
        User user = ehcacheService.findById("10000");
        System.out.println(user);

        System.out.println("-----------------------");

        //ehcacheService.removeUser("10000");//删除缓存

        System.out.println("-----------------------");
        User user2 = ehcacheService.findById("10000");
        System.out.println(user2);

    }


    @Test
    public void testRemoveAllUser(){
        ehcacheService.findById("1");
        ehcacheService.findById("2");
        System.out.println("---------------------------");
        //ehcacheService.removeAllUser();//删除所有的缓存

        ehcacheService.findById("1");
        ehcacheService.findById("2");

//      模拟从数据库中查询数据
//      模拟从数据库中查询数据
//      UserCache delete all
//      模拟从数据库中查询数据
//      模拟从数据库中查询数据
    }


}
