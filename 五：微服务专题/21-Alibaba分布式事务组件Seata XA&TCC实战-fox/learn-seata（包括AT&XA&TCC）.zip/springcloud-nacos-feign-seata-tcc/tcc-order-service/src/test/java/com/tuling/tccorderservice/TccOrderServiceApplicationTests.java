package com.tuling.tccorderservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TccOrderServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
