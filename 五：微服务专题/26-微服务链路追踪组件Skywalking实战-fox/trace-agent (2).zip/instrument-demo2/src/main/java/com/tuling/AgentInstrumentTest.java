package com.tuling;

/**
 * @author Fox
 */
public class AgentInstrumentTest {
    
    public static void main(String[] args) {
    
        HelloService helloService = new HelloService();
        helloService.say();
        helloService.say2();
        
    }
}
